from flask import Flask
import flask
import socket

app = Flask(__name__)
hostname = socket.gethostname()

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(("8.8.8.8", 80))
ip = s.getsockname()[0]
s.close()

@app.route("/")
def run():
    return flask.render_template('app.html', ip=ip, hostname=hostname)